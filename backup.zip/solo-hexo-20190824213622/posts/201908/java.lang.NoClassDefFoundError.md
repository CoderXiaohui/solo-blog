title: java.lang.NoClassDefFoundError
date: '2019-08-11 22:06:41'
updated: '2019-08-11 22:15:26'
tags: [java]
permalink: /articles/2019/08/11/1565532401394.html
---
> Exception in thread"main" java.lang.NoClassDefFoundError:org/apache/commons/lang/exception/NestableRuntimeException
使用环境： 项目中转json ,报了这个异常。

看了下json需要的jar包，都导入了。

查找了下原因，发现commons-collections-3.X.jar 和 commons-lang3-3.X.jar冲突的问题。

用**commons-lang 2.X** 就可以了。

（下载地址：http://www.cr173.com/soft/64964.html ）





**补充  json需要用到的包**：

json-lib-2.2.3-jdk15.jar

commons-beanutils-1.7.0.jar

commons-httpclient-3.1.jar

commons-lang-2.3.jar

commons-logging-1.1.1.jar

commons-collections-3.2.1.jar

ezmorph-1.0.3.jar

 

**没有的话会出现的异常**：

java.lang.NoClassDefFoundError: net/sf/ezmorph/Morpher

java.lang.NoClassDefFoundError: org/apache/commons/collections/map/ListOrderedMap

java.lang.NoClassDefFoundError: org/apache/commons/beanutils/DynaBean

java.lang.NoClassDefFoundError: org/apache/commons/codec/DecoderException

java.lang.NoClassDefFoundError: org/apache/commons/lang/exception/NestableRuntimeException

java.lang.NoClassDefFoundError: org/apache/commons/logging/LogFactory
