title: ajax传递数组后台接收不到值的问题
date: '2019-08-11 22:12:41'
updated: '2019-08-11 22:12:41'
tags: [AJAX]
permalink: /articles/2019/08/11/1565532761779.html
---
**背景：**

   JQGrid需要进行批量删除操作传给后台的是数组，结果后台接收不到值。    

   后台语言：java



**原因：**



> ajax传递参数时，traditional 默认为false，JQuery会深度序列化参数对象，为了适应别的框架，但是Servelt API 无法处理，所以我们要设置 traditional 的值为ture，使其进行传统的序列化方式。



```

$.ajax({

    type: 'post',

    url: '#',

    traditional:true,             //必须加！！！！！！需要这个值为true进行阻止深度序列化。

    data:{'userids':userids,'roleid':roleid},

    success: function(data) {

        }

    }

});

```

***官方文档解释：***

>traditional 

>类型：Boolean

>如果你想要用传统的方式来序列化数据，那么就设置为 true。

>Set this to true if you wish to use the traditional style of param serialization



参考：

http://blog.csdn.net/ojackhao/article/details/24580437

https://my.oschina.net/i33/blog/119506
